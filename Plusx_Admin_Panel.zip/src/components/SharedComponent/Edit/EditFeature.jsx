import React from 'react'

const EditFeature = () => {
  return (
    <div>EditFeature</div>
  )
}

export default EditFeature