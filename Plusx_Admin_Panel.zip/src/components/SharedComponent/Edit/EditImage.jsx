import React from 'react'

const EditImage = () => {
  return (
    <div>EditImage</div>
  )
}

export default EditImage