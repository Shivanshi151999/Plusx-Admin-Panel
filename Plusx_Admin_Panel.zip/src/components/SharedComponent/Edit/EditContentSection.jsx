import React from 'react'

const EditContentSection = () => {
  return (
    <div>EditContentSection</div>
  )
}

export default EditContentSection