import React from 'react'

const Graph = () => {
  return (
    <div>Graph</div>
  )
}

export default Graph