import React from 'react'
import Graph from './Graph/Graph'
import Cards from './Cards/Cards'
function Index() {
  return (
    <>
    <Graph />
    <Cards/>
    </>
  );
}

export default Index;