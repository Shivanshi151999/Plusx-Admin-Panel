import React from 'react'

const Cards = () => {
  return (
    <div>Cards</div>
  )
}

export default Cards