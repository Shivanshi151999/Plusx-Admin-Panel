// import React from 'react'
// import styles from './EmergencyDetails/emergency.module.css'
// import EmergencyCards from '../Riders/EmergencyDetails/EmergencyCards'
// import EmergencyDetails from '../Riders/EmergencyDetails/EmergencyDetails'
// import EmergencyList from '../Riders/EmergencyDetails/EmergencyList'

// const index = () => {
//   return (
//     <div className={styles.emergencyContainer}>
//       <EmergencyCards/>
//       <EmergencyDetails/>
//       <EmergencyList/>
//     </div>
//   )
// }

// export default index