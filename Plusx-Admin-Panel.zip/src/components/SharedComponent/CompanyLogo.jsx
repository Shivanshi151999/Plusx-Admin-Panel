import React from 'react'
import Logo from '../../assets/images/Logo.svg'

const CompanyLogo = () => {
  return <img src={Logo} alt="companyLogo" />;
}

export default CompanyLogo