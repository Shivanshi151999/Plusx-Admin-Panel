import React from 'react'
import Login from './login'
import styles from './login.module.css'
const index = () => {
  return (
    <div className={styles.LoginMainContainer}>
       <Login/> 
    </div>
  )
}

export default index