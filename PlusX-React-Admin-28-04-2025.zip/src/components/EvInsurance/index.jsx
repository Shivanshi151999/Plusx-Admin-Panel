import React from "react";
import { Outlet } from "react-router-dom";

const EvInsurance = () => {
  return (
    <div>
      <Outlet />
    </div>
  );
};

export default EvInsurance;