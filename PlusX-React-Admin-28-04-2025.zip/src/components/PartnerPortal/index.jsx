import React from "react";
import { Outlet } from "react-router-dom";

const Partners = () => {
  return (
    <div>
      <Outlet />
    </div>
  );
};

export default Partners;